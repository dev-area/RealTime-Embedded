#include<stdio.h>

#include "task.h"


int main()
{
	// TODO: 
	// create 2 tasks
	//		1. with priority 10 and running
	//		2. with priority 5 and suspended
	// print tasks status
	// destroy tasks
	return 0;
}