//*****************************************************************************
//
// hello_widget.c - Simple hello world example using
//
// Copyright (c) 2008-2010 Texas Instruments Incorporated.  All rights reserved.
// Software License Agreement
// 
// Texas Instruments (TI) is supplying this software for use solely and
// exclusively on TI's microcontroller products. The software is owned by
// TI and/or its suppliers, and is protected under applicable copyright
// laws. You may not combine this software with "viral" open-source
// software in order to form a larger program.
// 
// THIS SOFTWARE IS PROVIDED "AS IS" AND WITH ALL FAULTS.
// NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE APPLY TO THIS SOFTWARE. TI SHALL NOT, UNDER ANY
// CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
// DAMAGES, FOR ANY REASON WHATSOEVER.
// 
// This is part of revision 6734 of the DK-LM3S9B96 Firmware Package.
//
//*****************************************************************************

#include "inc/hw_types.h"
#include "driverlib/interrupt.h"
#include "driverlib/sysctl.h"
#include "grlib/grlib.h"
#include "grlib/widget.h"
#include "grlib/canvas.h"
#include "grlib/pushbutton.h"
#include "drivers/kitronix320x240x16_ssd2119_8bit.h"
#include "drivers/touch.h"
#include "drivers/set_pinout.h"
#include "driverlib/flash.h"
#include<stdio.h>

//*****************************************************************************
//
//! \addtogroup example_list
//! <h1>Hello using Widgets (hello_widget)</h1>
//!
//! A very simple ``hello world'' example written using the Stellaris Graphics
//! Library widgets.  It displays a button which, when pressed, toggles
//! display of the words ``Hello World!'' on the screen.  This may be used as
//! a starting point for more complex widget-based applications.
//
//*****************************************************************************

//*****************************************************************************
//
// Forward reference to various widget structures.
//
//*****************************************************************************
extern tCanvasWidget g_sBackground;
extern tCanvasWidget g_sMsgTemp;
extern tCanvasWidget g_sMsgVel;
extern tPushButtonWidget g_sPushBtnUpTemp;
extern tPushButtonWidget g_sPushBtnDownTemp;
extern tPushButtonWidget g_sPushBtnUpVel;
extern tPushButtonWidget g_sPushBtnDownVel;
extern tPushButtonWidget g_sPushBtnSave;


//*****************************************************************************
//
// Forward reference to the button press handler.
//
//*****************************************************************************
void OnUpTempPress(tWidget *pWidget);
void OnDownTempPress(tWidget *pWidget);
void OnUpVelPress(tWidget *pWidget);
void OnDownVelPress(tWidget *pWidget);
void OnSavePress(tWidget *pWidget);



Canvas(g_sBackground, WIDGET_ROOT, 0, &g_sPushBtnUpTemp,
       &g_sKitronix320x240x16_SSD2119, 0, 0, 320, 240,
       CANVAS_STYLE_FILL, ClrBlack, 0, 0, 0, 0, 0, 0);

RectangularButton(g_sPushBtnUpTemp, &g_sBackground, &g_sPushBtnDownTemp, 0,
                  &g_sKitronix320x240x16_SSD2119, 20, 20, 30, 30,
                  (PB_STYLE_OUTLINE | PB_STYLE_TEXT_OPAQUE | PB_STYLE_TEXT |
                   PB_STYLE_FILL | PB_STYLE_RELEASE_NOTIFY),
                   ClrDarkBlue, ClrBlue, ClrWhite, ClrWhite,
                   &g_sFontCm18b, "+", 0, 0, 0, 0, OnUpTempPress);

RectangularButton(g_sPushBtnDownTemp, &g_sBackground,  &g_sPushBtnUpVel, 0,
                  &g_sKitronix320x240x16_SSD2119, 60, 20, 30, 30,
                  (PB_STYLE_OUTLINE | PB_STYLE_TEXT_OPAQUE | PB_STYLE_TEXT |
                   PB_STYLE_FILL | PB_STYLE_RELEASE_NOTIFY),
                   ClrDarkBlue, ClrBlue, ClrWhite, ClrWhite,
                   &g_sFontCm18b, "-", 0, 0, 0, 0, OnDownTempPress);

RectangularButton(g_sPushBtnUpVel, &g_sBackground,  &g_sPushBtnDownVel, 0,
                  &g_sKitronix320x240x16_SSD2119, 20, 60, 30, 30,
                  (PB_STYLE_OUTLINE | PB_STYLE_TEXT_OPAQUE | PB_STYLE_TEXT |
                   PB_STYLE_FILL | PB_STYLE_RELEASE_NOTIFY),
                   ClrDarkBlue, ClrBlue, ClrWhite, ClrWhite,
                   &g_sFontCm18b, "+", 0, 0, 0, 0, OnUpVelPress);

RectangularButton(g_sPushBtnDownVel, &g_sBackground,  &g_sMsgTemp, 0,
                  &g_sKitronix320x240x16_SSD2119, 60, 60, 30, 30,
                  (PB_STYLE_OUTLINE | PB_STYLE_TEXT_OPAQUE | PB_STYLE_TEXT |
                   PB_STYLE_FILL | PB_STYLE_RELEASE_NOTIFY),
                   ClrDarkBlue, ClrBlue, ClrWhite, ClrWhite,
                   &g_sFontCm18b, "-", 0, 0, 0, 0, OnDownVelPress);

Canvas(g_sMsgTemp, &g_sBackground,  &g_sMsgVel, 0,
       &g_sKitronix320x240x16_SSD2119, 110, 20, 100, 30,
       (CANVAS_STYLE_FILL | CANVAS_STYLE_TEXT),
       ClrBlack, 0, ClrWhite, &g_sFontCm20b, "Temp: 0", 0, 0);

Canvas(g_sMsgVel, &g_sBackground, &g_sPushBtnSave, 0,
       &g_sKitronix320x240x16_SSD2119, 110, 60, 100, 30,
       (CANVAS_STYLE_FILL | CANVAS_STYLE_TEXT),
       ClrBlack, 0, ClrWhite, &g_sFontCm20b, "Vel:  0", 0, 0);

RectangularButton(g_sPushBtnSave, &g_sBackground,  0, 0,
                  &g_sKitronix320x240x16_SSD2119, 20, 210, 100, 30,
                  (PB_STYLE_OUTLINE | PB_STYLE_TEXT_OPAQUE | PB_STYLE_TEXT |
                   PB_STYLE_FILL | PB_STYLE_RELEASE_NOTIFY),
                   ClrDarkBlue, ClrBlue, ClrWhite, ClrWhite,
                   &g_sFontCm18b, "Save", 0, 0, 0, 0,OnSavePress );
//*****************************************************************************
//
// The error routine that is called if the driver library encounters an error.
//
//*****************************************************************************
#ifdef DEBUG
void
__error__(char *pcFilename, unsigned long ulLine)
{
}
#endif

int vel,temp;
char tempText[20];
char velText[20];

void OnUpTempPress(tWidget *pWidget)
{
	temp++;
	sprintf(tempText,"Temp: %d",temp);
    WidgetPaint((tWidget *)&g_sMsgTemp);
}
void OnDownTempPress(tWidget *pWidget)
{
	temp--;
	sprintf(tempText,"Temp: %d",temp);
    WidgetPaint((tWidget *)&g_sMsgTemp);
}
void OnUpVelPress(tWidget *pWidget)
{
	vel++;
	sprintf(velText,"Vel:  %d",vel);
    WidgetPaint((tWidget *)&g_sMsgVel);
}
void OnDownVelPress(tWidget *pWidget)
{
	vel--;
	sprintf(velText,"Vel:  %d",vel);
    WidgetPaint((tWidget *)&g_sMsgVel);
}

void OnSavePress(tWidget *pWidget)
{
	// todo: save data to the flash on address 0x20000
}
void LoadData()
{
	// todo: read data from flash

 	sprintf(tempText,"Temp:  %d",temp);
	sprintf(velText,"Vel:  %d",vel);
}


//*****************************************************************************
//
// Print "Hello World!" to the display on the Intelligent Display Module.
//
//*****************************************************************************
int main(void)
{
    //
    // Set the system clock to run at 50MHz from the PLL
    //
    SysCtlClockSet(SYSCTL_SYSDIV_4 | SYSCTL_USE_PLL | SYSCTL_OSC_MAIN |
                       SYSCTL_XTAL_16MHZ);

    //
    // Set the device pinout appropriately for this board.
    //
    PinoutSet();

    //
    // Enable Interrupts
    //
    IntMasterEnable();

    //
    // Initialize the display driver.
    //
    Kitronix320x240x16_SSD2119Init();

    //
    // Initialize the touch screen driver.
    //
    TouchScreenInit();

    //
    // Set the touch screen event handler.
    //
    TouchScreenCallbackSet(WidgetPointerMessage);

    //
    // Add the compile-time defined widgets to the widget tree.
    //
    WidgetAdd(WIDGET_ROOT, (tWidget *)&g_sBackground);

	LoadData();

	CanvasTextSet(&g_sMsgTemp,tempText);

	CanvasTextSet(&g_sMsgVel,velText);
   //
    // Paint the widget tree to make sure they all appear on the display.
    //
    WidgetPaint(WIDGET_ROOT);

//	TestFlash();
    //
    // Loop forever, processing widget messages.
    //
    while(1)
    {
        //
        // Process any messages from or for the widgets.
        //
        WidgetMessageQueueProcess();
    }
}
