//*****************************************************************************
//
// Forward reference to various widget structures.
//
//*****************************************************************************
#include "inc/hw_types.h"
#include "driverlib/interrupt.h"
#include "driverlib/sysctl.h"
#include "grlib/grlib.h"
#include "grlib/widget.h"
#include "grlib/canvas.h"
#include "grlib/pushbutton.h"
#include "drivers/kitronix320x240x16_ssd2119_8bit.h"
#include "full_display.h"
#include "display.h"

void OnTest1Press(tWidget *pWidget);

extern tPushButtonWidget g_sPushBtnTest1;

static tCanvasWidget *g_nextDisplay;

void InitFullDisplay(tCanvasWidget *next)
{
	g_nextDisplay = next;
}



Canvas(g_fullDisplayRoot, WIDGET_ROOT, 0, &g_sPushBtnTest1,
       &g_sKitronix320x240x16_SSD2119, 0, 0, 320, 240,
       CANVAS_STYLE_FILL, ClrBlack, 0, 0, 0, 0, 0, 0);

RectangularButton(g_sPushBtnTest1, &g_fullDisplayRoot, 0, 0,
                  &g_sKitronix320x240x16_SSD2119, 20, 20, 70, 30,
                  (PB_STYLE_OUTLINE | PB_STYLE_TEXT_OPAQUE | PB_STYLE_TEXT |
                   PB_STYLE_FILL | PB_STYLE_RELEASE_NOTIFY),
                   ClrDarkBlue, ClrBlue, ClrWhite, ClrWhite,
                   &g_sFontCm18b, "test full", 0, 0, 0, 0, OnTest1Press);


void OnTest1Press(tWidget *pWidget)
{
	WidgetRemove((tWidget *)&g_fullDisplayRoot);
	SwitchDisplay(g_nextDisplay);
}

