// commbase.h
