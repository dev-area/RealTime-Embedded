#include "grlib/grlib.h"
#include "grlib/widget.h"
#include "grlib/canvas.h"
#include "grlib/pushbutton.h"


void SwitchDisplay(tCanvasWidget *displayRoot);
void InitDisplays(void);
