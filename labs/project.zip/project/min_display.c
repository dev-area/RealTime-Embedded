//*****************************************************************************
//
// Forward reference to various widget structures.
//
//*****************************************************************************
#include "inc/hw_types.h"
#include "driverlib/interrupt.h"
#include "driverlib/sysctl.h"
#include "grlib/grlib.h"
#include "grlib/widget.h"
#include "grlib/canvas.h"
#include "grlib/pushbutton.h"
#include "drivers/kitronix320x240x16_ssd2119_8bit.h"
#include "min_display.h"
#include "display.h"


extern tPushButtonWidget g_minPushBtnTest1;

//*****************************************************************************
//
// Forward reference to the button press handler.
//
//*****************************************************************************
static void OnTest2Press(tWidget *pWidget);

static tCanvasWidget *g_nextDisplay;

void InitMinDisplay(tCanvasWidget *next)
{
	g_nextDisplay = next;
}


Canvas(g_minDisplayRoot, WIDGET_ROOT, 0, &g_minPushBtnTest1,
       &g_sKitronix320x240x16_SSD2119, 0, 0, 320, 240,
       CANVAS_STYLE_FILL, ClrBlack, 0, 0, 0, 0, 0, 0);

RectangularButton(g_minPushBtnTest1, &g_minDisplayRoot, 0, 0,
                  &g_sKitronix320x240x16_SSD2119, 120, 20, 70, 30,
                  (PB_STYLE_OUTLINE | PB_STYLE_TEXT_OPAQUE | PB_STYLE_TEXT |
                   PB_STYLE_FILL | PB_STYLE_RELEASE_NOTIFY),
                   ClrDarkBlue, ClrBlue, ClrWhite, ClrWhite,
                   &g_sFontCm18b, "test2", 0, 0, 0, 0, OnTest2Press);


static void OnTest2Press(tWidget *pWidget)
{
	WidgetRemove((tWidget *)&g_minDisplayRoot);
	SwitchDisplay(g_nextDisplay);
}


