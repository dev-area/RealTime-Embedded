#include "grlib/grlib.h"
#include "grlib/widget.h"
#include "grlib/canvas.h"
#include "grlib/pushbutton.h"

void InitFullDisplay(tCanvasWidget *next);

extern tCanvasWidget g_fullDisplayRoot;
