#include "grlib/grlib.h"
#include "grlib/widget.h"
#include "grlib/canvas.h"
#include "grlib/pushbutton.h"

void InitMinDisplay(tCanvasWidget *next);

extern tCanvasWidget g_minDisplayRoot;
