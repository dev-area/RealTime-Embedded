

#include "display.h"
#include "full_display.h"
#include "min_display.h"




void SwitchDisplay(tCanvasWidget *displayRoot)
{
	//
    // Add the compile-time defined widgets to the widget tree.
    //
    WidgetAdd(WIDGET_ROOT, (tWidget *)displayRoot);


    //
    // Paint the widget tree to make sure they all appear on the display.
    //
    WidgetPaint(WIDGET_ROOT);

}

void InitDisplays(void)
{
	InitMinDisplay(&g_fullDisplayRoot);
	InitFullDisplay(&g_minDisplayRoot);

	SwitchDisplay(&g_minDisplayRoot);

}

