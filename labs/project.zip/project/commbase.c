// commbase.c
// comunication base for uart messages
// state machine to handles the base header and trailer for message
// message structure:
//					0xAA
//					0xBB
//					Message Len
//					data
//					data
//					...
//					Checksum

#include "commbase.h"