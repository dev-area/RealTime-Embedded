 /************************************************************/
/* PROJECT NAME: Exe			                          	*/
/* Project:      LPC2100 Training course                    */
/* Engineer:     T Martin        tmartin@hitex.co.uk        */
/* Filename:     main.c                                     */
/* Language:     C                      	                */
/* Compiler:     Keil ARM	V2.11		                    */
/* Assembler:    				                            */
/* O/S:			RTL RTOS                                    */
/************************************************************/
/* COPYRIGHT: Hitex UK Ltd 		2005						*/
/* LICENSE:   THIS VERSION CREATED FOR FREE DISTRIBUTION	*/
/************************************************************/
/* Function:                                                */
/*                                                          */
/* Example 									           		*/
/*															*/
/* Demonstrates the use of user timers in RTL RTOS     		*/
/*															*/	
/* Oscillator frequency 12.000 Mhz							*/
/* Target board Keil MCB21000								*/
/************************************************************/

#include <rtl.h>
#include <LPC21xx.H> 

void task1 (void);
void task2 (void);
void task3 (void);
void task4 (void);
OS_TID tsk1,tsk2,tsk3,tsk4;
OS_ID tmr1,tmr2;

void main (void)
{
IODIR0 	= 0xFF;

os_sys_init (task1);
}

void task1 (void)	
{

tsk1 	= os_tsk_self();
// TODO: create 3 tasks - priority 1
// task2() , task3(), task4()

while(1)
{
}
}

void task2 (void)	
{
	// TODO: wait for task3 and task4 to finish
	IOSET0 	=  0xFF;

	//TODO: delete the task
}

void task3 (void)
{
	// TODO: delay for 100

	// TODO: notify task2 

	// TODO: delete the task
}

void task4 (void)
{
	// TODO: delay for 100

	// TODO: notify task2 

	// TODO: delete the task
}

// PART 2
// TODO: use the same function for task3 and task4

